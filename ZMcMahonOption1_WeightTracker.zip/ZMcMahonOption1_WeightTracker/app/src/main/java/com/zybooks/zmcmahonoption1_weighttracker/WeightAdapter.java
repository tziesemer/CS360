package com.zybooks.zmcmahonoption1_weighttracker;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class WeightAdapter extends ArrayAdapter<Weight> {
    public WeightAdapter(Context context, List<Weight> weights){
        super(context,0, weights);
    }



    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Weight weight = getItem(position);

        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.weight_cell, parent,false);

        }

        TextView newWeight = convertView.findViewById(R.id.cellWeight);
        TextView newDate = convertView.findViewById(R.id.cellDate);
        Button editButton = convertView.findViewById(R.id.edit_button);
        Button removeButton = convertView.findViewById(R.id.remove_button);

        View finalConvertView = convertView;
        removeButton.setOnClickListener(new View.OnClickListener() {
            int newID = weight.getId();
            @Override

            public void onClick(View v) {
                weight.removeItem(newID);
                notifyDataSetChanged();
                SQLiteManager sqLiteManager = new SQLiteManager(getContext());
                sqLiteManager.deleteWeightInDatabase(newID);
            }
        });

        editButton.setOnClickListener(new View.OnClickListener() {
            int newID = weight.getId();

            @Override
            public void onClick(View v) {

                AlertDialog.Builder alert = new AlertDialog.Builder(getContext());
                LinearLayout layout = new LinearLayout(getContext());
                layout.setOrientation(LinearLayout.VERTICAL);

                final TextView newWeightLabel = new TextView(getContext());
                newWeightLabel.setText("New Weight");
                layout.addView(newWeightLabel);
                final EditText newWeightData = new EditText(getContext());
                newWeightData.setHint("Enter new weight");
                newWeightData.setInputType(InputType.TYPE_NUMBER_FLAG_DECIMAL);
                layout.addView(newWeightData);

                final TextView newDateLabel = new TextView(getContext());
                newDateLabel.setText("New Date");
                layout.addView(newDateLabel);
                final EditText newDateData = new EditText(getContext());
                newDateData.setHint("Enter new date");
                newDateData.setInputType(InputType.TYPE_DATETIME_VARIATION_DATE);
                layout.addView(newDateData);

                alert.setPositiveButton("Submit", (DialogInterface.OnClickListener) (dialog, which) -> {
                    SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(getContext());
                    Weight newWeight = new Weight(newID, String.valueOf(newWeightData.getText()),
                            String.valueOf(newDateData.getText()));
                    sqLiteManager.updateWeightInDatabase(newWeight);
                    weight.updateItem(newWeight);
                    notifyDataSetChanged();
                    dialog.cancel();
                });
                alert.setView(layout);
                alert.show();
            }
        });

        newWeight.setText(String.valueOf(weight.getWeight()));
        newDate.setText(String.valueOf(weight.getInput()));

        return convertView;
    }

}
