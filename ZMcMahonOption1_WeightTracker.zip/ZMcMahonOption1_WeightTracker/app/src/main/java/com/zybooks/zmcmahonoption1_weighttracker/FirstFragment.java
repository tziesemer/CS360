package com.zybooks.zmcmahonoption1_weighttracker;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.zybooks.zmcmahonoption1_weighttracker.databinding.FragmentFirstBinding;

public class FirstFragment extends Fragment {

    private FragmentFirstBinding binding;

    private EditText usernameEditText, passwordAccountEditText;

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        binding = FragmentFirstBinding.inflate(inflater, container, false);
        initWidgits(binding);
        return binding.getRoot();

    }

    private void initWidgits(FragmentFirstBinding binding) {

        usernameEditText =  binding.getRoot().findViewById(R.id.textUsername);
        passwordAccountEditText = binding.getRoot().findViewById(R.id.textPassword);

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.loginButton.setOnClickListener( new View.OnClickListener() {

                    public void onClick(View view) {

                        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(getContext());
                        String username = String.valueOf(usernameEditText.getText());
                        String password = String.valueOf(passwordAccountEditText.getText());
                        if (sqLiteManager.login(username, password)) {

                            NavHostFragment.findNavController(FirstFragment.this)
                                    .navigate(R.id.action_FirstFragment_to_SecondFragment);
                        } else {
                            Toast toast = Toast.makeText(getContext(),
                                    "Incorrect username or password", Toast.LENGTH_SHORT);
                            toast.show();
                        }
                    }
                                                });
              binding.createAccountButton.setOnClickListener(new View.OnClickListener() {
                  @Override
                  public void onClick(View v) {
                      SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(getContext());
                      String username = String.valueOf(usernameEditText.getText());
                      String password = String.valueOf(passwordAccountEditText.getText());
                      if(sqLiteManager.checkForUsername(username)){
                          Toast toast = Toast.makeText(getContext(),
                                  "Username already exists", Toast.LENGTH_SHORT);
                          toast.show();
                      }
                      else {
                          sqLiteManager.addLogin(username, password);
                          NavHostFragment.findNavController(FirstFragment.this)
                                  .navigate(R.id.action_FirstFragment_to_SecondFragment);
                      }
                  }
              });
            }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}