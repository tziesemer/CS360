package com.zybooks.zmcmahonoption1_weighttracker;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.os.Binder;
import android.os.Bundle;
import android.renderscript.ScriptGroup;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.Manifest;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.zybooks.zmcmahonoption1_weighttracker.databinding.FragmentSecondBinding;

import org.w3c.dom.Text;

public class SecondFragment extends Fragment {

    private FragmentSecondBinding binding;

    public GridView weightGridView;

    private TextView goalWeightTextView;




    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentSecondBinding.inflate(inflater, container, false);
        initWidgits(binding);
        setWeightAdapter(binding);
        setGoalWeightValue();
        return binding.getRoot();

    }

    private void setGoalWeightValue() {
        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(getContext());
        TextView goalWeightTextView = binding.getRoot().findViewById(R.id.goal_weight_text);
        goalWeightTextView.setText(String.format("Goal: %slbs", sqLiteManager.getGoalWeight()));
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.addWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(getContext());
                sqLiteManager.setUpdate(false);
                NavHostFragment.findNavController(SecondFragment.this)
                        .navigate(R.id.action_SecondFragment_to_WeightDataActivity);
            }
        });

        binding.editGoalWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alert = new AlertDialog.Builder(getContext());
                LinearLayout layout = new LinearLayout(getContext());
                layout.setOrientation(LinearLayout.VERTICAL);

                final TextView goalWeightText = new TextView(getContext());
                goalWeightText.setText("Goal Weight");
                layout.addView(goalWeightText);
                final EditText weightBox = new EditText(getContext());
                weightBox.setHint("Goal Weight");
                layout.addView(weightBox); // Notice this is an add method

                alert.setPositiveButton("Submit", (DialogInterface.OnClickListener)(dialog, which) ->{
                    SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(getContext());
                    sqLiteManager.setGoalWeight(weightBox.getText().toString());
                    setGoalWeightValue();
                    dialog.cancel();
                });



                alert.setView(layout);
                alert.show();

                String permission = "Requesting permission to send you a SMS when goal weight is reached.";
                if(ContextCompat.checkSelfPermission(getActivity(),
                        Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {

                    ActivityCompat.requestPermissions(getActivity(),
                            new String[]{String.valueOf(Manifest.permission.SEND_SMS)}, 100);

                        AlertDialog.Builder numAlert = new AlertDialog.Builder(getContext());
                        LinearLayout numLayout = new LinearLayout(getContext());
                        numLayout.setOrientation(LinearLayout.VERTICAL);

                        final TextView phoneNumRequest = new TextView(getContext());
                        phoneNumRequest.setText("Device Phone Number");
                        numLayout.addView(phoneNumRequest);
                        final EditText phoneNumber = new EditText(getContext());
                        phoneNumber.setHint("Device Phone Number");
                        numLayout.addView(phoneNumber);

                        numAlert.setPositiveButton("Submit", (DialogInterface.OnClickListener) (dialog, which) -> {
                            SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(getContext());
                            sqLiteManager.setPhoneNum(phoneNumber.getText().toString());
                            dialog.cancel();
                        });

                        numAlert.setView(numLayout);
                        numAlert.show();

                }
                // Again this is a set method, not add
            }
        });
    }


    private void setWeightAdapter(FragmentSecondBinding binding) {
        WeightAdapter weightAdapter = new WeightAdapter(binding.getRoot().getContext(), Weight.weightArrayList);
        weightGridView.setAdapter(weightAdapter);
    }

    private void initWidgits(FragmentSecondBinding binding) {
        weightGridView = binding.getRoot().findViewById(R.id.weightGridView);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}