package com.zybooks.zmcmahonoption1_weighttracker;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telecom.TelecomManager;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.view.View.OnClickListener;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import android.widget.Button;
import android.widget.TextView;

import com.zybooks.zmcmahonoption1_weighttracker.databinding.FragmentWeightDataBinding;

import java.util.Date;


public class WeightDataFragment extends Fragment {


    private FragmentWeightDataBinding binding;

    private EditText weightEditText;
    private TextView dateTextView;


    private void initWidgits(FragmentWeightDataBinding binding) {

        weightEditText = binding.getRoot().findViewById(R.id.add_weight);
        dateTextView = binding.getRoot().findViewById(R.id.add_date);

    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentWeightDataBinding.inflate(inflater, container, false);
        initWidgits(binding);
        Button addWeightButton = binding.getRoot().findViewById(R.id.add_weight_button);
        Button selectDateButton = binding.getRoot().findViewById(R.id.pickTime);

        selectDateButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerFragment newDate = new DatePickerFragment();
                newDate.show(getActivity().getSupportFragmentManager(), "datePicker");
            }
        });

        addWeightButton.setOnClickListener(new OnClickListener(){

            public void onClick(View view) {
                SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(getContext());
                String weight = String.valueOf(weightEditText.getText());
                String date = String.valueOf(dateTextView.getText());
                int id = Weight.weightArrayList.size();
                Weight newWeight = new Weight(id, weight, date);
                Weight.weightArrayList.add(newWeight);
                sqLiteManager.addWeightToDatabase(newWeight);

                if (ContextCompat.checkSelfPermission(getActivity(),
                        Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    if (weight.equals(sqLiteManager.getGoalWeight())) {

                        String phoneNum = sqLiteManager.getPhoneNum();

                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phoneNum, null,
                                "You reached your weight goal!", null, null);
                    }
                }
                NavHostFragment.findNavController(WeightDataFragment.this)
                        .navigate(R.id.action_WeightDataFragment_to_SecondFragment);
            }
        });

        Button cancelButton = binding.getRoot().findViewById(R.id.cancel_add_weight_button);
        cancelButton.setOnClickListener(new OnClickListener(){

            public void onClick(View view){

                NavHostFragment.findNavController(WeightDataFragment.this)
                        .navigate(R.id.action_WeightDataFragment_to_SecondFragment);

            }
        });
        return binding.getRoot();

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}