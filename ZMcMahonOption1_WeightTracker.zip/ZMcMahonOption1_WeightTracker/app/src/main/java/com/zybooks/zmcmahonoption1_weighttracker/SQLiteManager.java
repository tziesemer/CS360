package com.zybooks.zmcmahonoption1_weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;


public class SQLiteManager extends SQLiteOpenHelper {

    private boolean isUpdate = false;

    private static SQLiteManager sqLiteManager;

    private String phoneNum;
    private static String DATABASE_NAME = "WeightDB";
    private static int DATABASE_VERSION = 1;
    private static String TABLE_NAME = "Weights";
    private static String COUNTER = "Counter";
    private static String ID_FIELD = "id";
    private static String WEIGHT_FIELD = "Weight";
    private static String DATE_FIELD = "DateTaken";
    private static DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");


    private static String LOGIN_TABLE_NAME = "Logins";
    private static String USERNAME_FIELD = "Username";
    private static String PASSWORD_FIELD = "Password";

    private static String GOAL_TABLE_NAME = "Goal";
    private static String GOAL_WEIGHT_FIELD = "GoalWeight";
    public SQLiteManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    public static SQLiteManager instanceOfDatabase(Context context){
        
        if(sqLiteManager == null){
            sqLiteManager = new SQLiteManager(context);
        }

        return sqLiteManager;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        StringBuilder sql;
        sql = new StringBuilder()
                .append("CREATE TABLE ")
                .append(TABLE_NAME)
                .append("(")
                .append(COUNTER)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(ID_FIELD)
                .append(" INT,")
                .append(WEIGHT_FIELD)
                .append(" TEXT, ")
                .append(DATE_FIELD)
                .append(" TEXT)");

        db.execSQL(sql.toString());

        StringBuilder loginSql;
        loginSql = new StringBuilder()
                .append("CREATE TABLE ")
                .append(LOGIN_TABLE_NAME)
                .append("(")
                .append(COUNTER)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(USERNAME_FIELD)
                .append(" TEXT, ")
                .append(PASSWORD_FIELD)
                .append(" TEXT)");
        db.execSQL(loginSql.toString());

        StringBuilder goalSql;
        goalSql = new StringBuilder()
                .append("CREATE TABLE ")
                .append(GOAL_TABLE_NAME)
                .append("(")
                .append(COUNTER)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(ID_FIELD)
                .append(" INT,")
                .append(GOAL_WEIGHT_FIELD)
                .append(" TEXT)");
        db.execSQL(goalSql.toString());

        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, 1);
        contentValues.put(GOAL_WEIGHT_FIELD, "000");
        db.insert(GOAL_TABLE_NAME, null, contentValues);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {


    }

    public void addWeightToDatabase(Weight weight){


        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, weight.getId());
        contentValues.put(WEIGHT_FIELD, weight.getWeight());
        contentValues.put(DATE_FIELD, weight.getInput());

        sqLiteDatabase.insert(TABLE_NAME, null, contentValues);

    }

    public void populateWeightListArray(){

        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + TABLE_NAME, null)){
            if(result.getCount() != 0){
                while(result.moveToNext()){
                    int id = result.getInt(1);
                    String weight = result.getString(2);
                    String date = result.getString(3);
                    Weight newWeight = new Weight(id,weight,date);
                    Weight.weightArrayList.add(newWeight);
                }
            }
        }
    }

    public void updateWeightInDatabase(Weight weight){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        System.out.println(weight);
        ContentValues contentValues = new ContentValues();

        contentValues.put(ID_FIELD, weight.getId());
        contentValues.put(WEIGHT_FIELD, weight.getWeight());
        contentValues.put(DATE_FIELD, weight.getInput());

        sqLiteDatabase.update(TABLE_NAME, contentValues, ID_FIELD + " =? ",
                new String[]{String.valueOf(weight.getId())});
    }

    public void deleteWeightInDatabase(int id){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        sqLiteDatabase.delete(TABLE_NAME, ID_FIELD + " =?", new String[]{String.valueOf(id)});
    }

    public boolean login(String username, String password){
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + LOGIN_TABLE_NAME, null)){

            if(result.getCount() != 0){
                while(result.moveToNext()){
                    String compareUsername = result.getString(1);
                    if(compareUsername.equals(username)){
                        String comparePassword = result.getString(2);
                        if(comparePassword.equals(password)){
                            return true;
                        }
                    }
                }
            }
            return false;
    }
    }

    public boolean checkForUsername(String username){
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + LOGIN_TABLE_NAME, null)){
            if(result.getCount() != 0){
                while(result.moveToNext()){
                    if (result.getString(1).equals(username)){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public void addLogin(String username, String password){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(USERNAME_FIELD, username);
        contentValues.put(PASSWORD_FIELD, password);

        sqLiteDatabase.insert(LOGIN_TABLE_NAME, null, contentValues);
    }

    public String getGoalWeight(){
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + GOAL_TABLE_NAME, null)){
            while (result.moveToNext()){
            if(result.getCount() != 0) {
                return result.getString(2);
            }
            }
        }
      return "goal weight not found";
    }

    public void setGoalWeight(String newWeight){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(ID_FIELD, 1);
        contentValues.put(GOAL_WEIGHT_FIELD, newWeight);

        sqLiteDatabase.update(GOAL_TABLE_NAME, contentValues,
                ID_FIELD + " =? ", new String[]{String.valueOf(1)});
    }

    public String getPhoneNum() {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + GOAL_TABLE_NAME, null)) {
            while (result.moveToNext()) {
                if (result.getCount() != 0) {
                    if (result.getString(1).equals("2")) {
                        return result.getString(2);
                    }
                }
            }
        }
        return "1-999-999-9999";
    }

    public void setPhoneNum(String phoneNum) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(ID_FIELD, 2);
        contentValues.put(GOAL_WEIGHT_FIELD, phoneNum);
        sqLiteDatabase.update(GOAL_TABLE_NAME, contentValues,
                ID_FIELD + " = ? ", new String[]{String.valueOf(2)});
    }

    public boolean isUpdate() {
        return isUpdate;
    }

    public void setUpdate(boolean update) {
        isUpdate = update;
    }
}