package com.zybooks.zmcmahonoption1_weighttracker;

import java.util.ArrayList;

public class Weight {

    public static ArrayList<Weight> weightArrayList = new ArrayList<>();
    private int id;
    private String weight;
    private String input;

    public Weight(int id, String weight, String input) {
        this.id = id;
        this.weight = weight;
        this.input = input;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getInput() {
        return input;
    }

    public void setInput(String input) {
        this.input = input;
    }

    public void removeItem(int removeID){
        Weight weight1 = getWeightForID(removeID);
        weightArrayList.remove(weight1);
    }

    public void updateItem(Weight weight){
        Weight weight1 = getWeightForID(weight.getId());
        weightArrayList.set(weightArrayList.indexOf(weight1), weight);
    }

    public static Weight getWeightForID(int passedID){

        for (Weight weight1 : weightArrayList){
            if(weight1.getId() == passedID){
                return weight1;
            }
        }
        return null;
    }
}
